# plot random process via matplotlib

import matplotlib.pyplot as plt
import numpy as np

def plotRandom():
    n = 50
    x = np.random.rand(n)
    y = np.random.rand(n)

    plt.scatter(x, y)
    plt.show()